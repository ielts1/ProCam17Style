package com.skp.procam17;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExposureState;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.camera.extensions.ExtensionMode;
import androidx.camera.extensions.ExtensionsManager;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_CAMERA = 1001;
    private FrameLayout root;
    private PreviewView previewView;
    private View gridView, shutterButton;
    private TextView flashButton, cameraButton, zoomButton, modeButton, exposureMinus, exposurePlus, statusText;
    private ProcessCameraProvider cameraProvider;
    private ExtensionsManager extensionsManager;
    private Camera camera;
    private ImageCapture imageCapture;
    private ExecutorService cameraExecutor;
    private boolean front = false, grid = false;
    private int flashMode = ImageCapture.FLASH_MODE_AUTO;
    private float currentZoom = 1f;
    private int exposureIndex = 0;
    private int modeIndex = 0;
    private final int[] modes = {ExtensionMode.AUTO, ExtensionMode.HDR, ExtensionMode.NIGHT, ExtensionMode.BOKEH};
    private final String[] modeNames = {"AUTO", "HDR", "NIGHT", "PORTRAIT"};
    private ScaleGestureDetector scaleDetector;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        root = new FrameLayout(this);
        setContentView(root);
        buildUi();
        cameraExecutor = Executors.newSingleThreadExecutor();
        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (camera != null) {
                    float next = currentZoom * d.getScaleFactor();
                    float min = camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();
                    float max = camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();
                    currentZoom = Math.max(min, Math.min(max, next));
                    camera.getCameraControl().setZoomRatio(currentZoom);
                    updateZoomText();
                }
                return true;
            }
        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        } else startCamera();
    }

    private void buildUi() {
        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        gridView = new GridOverlay(this);
        gridView.setVisibility(View.GONE);
        root.addView(gridView, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout top = new FrameLayout(this);
        top.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.addView(top, new FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP));
        flashButton = pill("AUTO"); addTop(top, flashButton, Gravity.START); flashButton.setOnClickListener(v -> cycleFlash());
        modeButton = pill("AUTO"); addTop(top, modeButton, Gravity.CENTER_HORIZONTAL); modeButton.setOnClickListener(v -> cycleMode());
        cameraButton = pill("↻"); FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(58), dp(42), Gravity.END); cp.topMargin=dp(8); top.addView(cameraButton, cp); cameraButton.setTextSize(22); cameraButton.setOnClickListener(v->{front=!front; startCamera();});

        statusText = new TextView(this); statusText.setText("SMART CAMERA • 4:3 • QUALITY 100"); statusText.setTextColor(Color.WHITE); statusText.setTextSize(10); statusText.setGravity(Gravity.CENTER); statusText.setAlpha(.75f);
        FrameLayout.LayoutParams st = new FrameLayout.LayoutParams(-1, dp(32), Gravity.TOP); st.topMargin=dp(62); root.addView(statusText, st);

        TextView gridButton = pill("GRID"); FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(64), dp(38), Gravity.TOP|Gravity.END); gp.topMargin=dp(96); gp.rightMargin=dp(12); root.addView(gridButton,gp);
        gridButton.setOnClickListener(v->{grid=!grid;gridView.setVisibility(grid?View.VISIBLE:View.GONE);gridButton.setAlpha(grid?1f:.65f);});

        FrameLayout controls = new FrameLayout(this); FrameLayout.LayoutParams cb = new FrameLayout.LayoutParams(-1,dp(58),Gravity.BOTTOM); cb.bottomMargin=dp(126); root.addView(controls,cb);
        exposureMinus=pill("−"); FrameLayout.LayoutParams em=new FrameLayout.LayoutParams(dp(54),dp(42),Gravity.START|Gravity.CENTER_VERTICAL); em.leftMargin=dp(18); controls.addView(exposureMinus,em); exposureMinus.setOnClickListener(v->changeExposure(-1));
        zoomButton=pill("1×"); FrameLayout.LayoutParams zm=new FrameLayout.LayoutParams(dp(82),dp(42),Gravity.CENTER); controls.addView(zoomButton,zm); zoomButton.setOnClickListener(v->cycleZoom());
        exposurePlus=pill("+"); FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(dp(54),dp(42),Gravity.END|Gravity.CENTER_VERTICAL); ep.rightMargin=dp(18); controls.addView(exposurePlus,ep); exposurePlus.setOnClickListener(v->changeExposure(1));

        shutterButton=new View(this); shutterButton.setBackground(circle(Color.WHITE)); FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(86),dp(86),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); sp.bottomMargin=dp(28); root.addView(shutterButton,sp); shutterButton.setOnClickListener(v->takePhoto());
        TextView hint=new TextView(this); hint.setText("Tap to focus  •  Pinch to zoom  •  Hold steady for HDR/Night"); hint.setTextColor(Color.WHITE); hint.setTextSize(10); hint.setAlpha(.65f); hint.setGravity(Gravity.CENTER); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(28),Gravity.BOTTOM); hp.bottomMargin=dp(4); root.addView(hint,hp);

        previewView.setOnTouchListener((v,e)->{scaleDetector.onTouchEvent(e); if(e.getAction()==MotionEvent.ACTION_UP&&camera!=null){MeteringPointFactory f=previewView.getMeteringPointFactory();FocusMeteringAction a=new FocusMeteringAction.Builder(f.createPoint(e.getX(),e.getY())).setAutoCancelDuration(3,TimeUnit.SECONDS).build();camera.getCameraControl().startFocusAndMetering(a);} return true;});
    }

    private void addTop(FrameLayout p, View v, int g){FrameLayout.LayoutParams x=new FrameLayout.LayoutParams(dp(76),dp(42),g);x.topMargin=dp(8);p.addView(v,x);}
    private TextView pill(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(11);t.setGravity(Gravity.CENTER);t.setBackground(round(Color.argb(165,0,0,0),dp(21)));t.setPadding(dp(4),0,dp(4),0);return t;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);d.setStroke(dp(1),Color.argb(70,255,255,255));return d;}
    private GradientDrawable circle(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setShape(GradientDrawable.OVAL);d.setStroke(dp(4),Color.WHITE);return d;}

    private void startCamera(){
        cameraExecutor.execute(() -> {
            final CameraSelector base = new CameraSelector.Builder().requireLensFacing(front?CameraSelector.LENS_FACING_FRONT:CameraSelector.LENS_FACING_BACK).build();
            ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
            future.addListener(()->{try{cameraProvider=future.get();
                ListenableFuture<ExtensionsManager> ef=ExtensionsManager.getInstanceAsync(this,cameraProvider);
                ef.addListener(()->{try{extensionsManager=ef.get(); bindCamera(base);}catch(Exception e){bindNormal(base);}},ContextCompat.getMainExecutor(this));
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Camera start failed",Toast.LENGTH_LONG).show());}},ContextCompat.getMainExecutor(this));
        });
    }

    private void bindCamera(CameraSelector base){
        int requested=modes[modeIndex];
        if(front && requested!=ExtensionMode.NONE){requested=ExtensionMode.NONE;}
        if(extensionsManager!=null && requested!=ExtensionMode.NONE && extensionsManager.isExtensionAvailable(base,requested)) bindWithExtension(base,requested); else bindNormal(base);
    }
    private void bindWithExtension(CameraSelector base,int mode){
        try{cameraProvider.unbindAll();
            CameraSelector ext=extensionsManager.getExtensionEnabledCameraSelector(base,mode);
            Preview preview=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build(); preview.setSurfaceProvider(previewView.getSurfaceProvider());
            imageCapture=new ImageCapture.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setJpegQuality(100).setFlashMode(flashMode).build();
            camera=cameraProvider.bindToLifecycle(this,ext,preview,imageCapture); finishBind();
            runOnUiThread(()->statusText.setText("SMART " + modeNames[modeIndex] + " • VENDOR PROCESSING • 4:3"));
        }catch(Exception e){bindNormal(base);}
    }
    private void bindNormal(CameraSelector base){
        try{cameraProvider.unbindAll();Preview preview=new Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build();preview.setSurfaceProvider(previewView.getSurfaceProvider());imageCapture=new ImageCapture.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setJpegQuality(100).setFlashMode(flashMode).build();camera=cameraProvider.bindToLifecycle(this,base,preview,imageCapture);finishBind();runOnUiThread(()->statusText.setText("SMART AUTO • STANDARD CAMERA • 4:3"));}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Camera unavailable",Toast.LENGTH_LONG).show());}}
    private void finishBind(){float min=camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();float max=camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();currentZoom=Math.max(min,Math.min(1f,max));camera.getCameraControl().setZoomRatio(currentZoom);updateZoomText();updateExposureButtons();}

    private void cycleMode(){modeIndex=(modeIndex+1)%modes.length;modeButton.setText(modeNames[modeIndex]);startCamera();}
    private void cycleFlash(){flashMode=flashMode==ImageCapture.FLASH_MODE_AUTO?ImageCapture.FLASH_MODE_ON:flashMode==ImageCapture.FLASH_MODE_ON?ImageCapture.FLASH_MODE_OFF:ImageCapture.FLASH_MODE_AUTO;flashButton.setText(flashMode==0?"AUTO":flashMode==1?"ON":"OFF");if(imageCapture!=null)imageCapture.setFlashMode(flashMode);}
    private void cycleZoom(){float min=camera==null?.5f:camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();float max=camera==null?2f:camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();float next=currentZoom<.75f?1f:currentZoom<1.5f?2f:min;currentZoom=Math.max(min,Math.min(max,next));if(camera!=null)camera.getCameraControl().setZoomRatio(currentZoom);updateZoomText();}
    private void updateZoomText(){if(zoomButton==null)return;if(Math.abs(currentZoom-.5f)<.08f)zoomButton.setText("0.5×");else if(Math.abs(currentZoom-1f)<.08f)zoomButton.setText("1×");else if(Math.abs(currentZoom-2f)<.12f)zoomButton.setText("2×");else zoomButton.setText(String.format(Locale.US,"%.1f×",currentZoom));}
    private void changeExposure(int d){if(camera==null)return;ExposureState es=camera.getCameraInfo().getExposureState();if(!es.isExposureCompensationSupported())return;int step=Math.max(1,es.getExposureCompensationStep().getNumerator());int lo=es.getExposureCompensationRange().getLower(),hi=es.getExposureCompensationRange().getUpper();exposureIndex=Math.max(lo,Math.min(hi,exposureIndex+d*step));camera.getCameraControl().setExposureCompensationIndex(exposureIndex);}
    private void updateExposureButtons(){if(camera==null)return;boolean ok=camera.getCameraInfo().getExposureState().isExposureCompensationSupported();exposureMinus.setAlpha(ok?1:.35f);exposurePlus.setAlpha(ok?1:.35f);}

    private void takePhoto(){if(imageCapture==null)return;shutterButton.animate().scaleX(.88f).scaleY(.88f).setDuration(65).withEndAction(()->shutterButton.animate().scaleX(1f).scaleY(1f).setDuration(90)).start();String name="ProCam17_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".jpg";ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/ProCam17Style");ImageCapture.OutputFileOptions out=new ImageCapture.OutputFileOptions.Builder(getContentResolver(),MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v).build();imageCapture.takePicture(out,cameraExecutor,new ImageCapture.OnImageSavedCallback(){@Override public void onImageSaved(@NonNull ImageCapture.OutputFileResults r){runOnUiThread(()->Toast.makeText(MainActivity.this,"Photo saved",Toast.LENGTH_SHORT).show());}@Override public void onError(@NonNull ImageCaptureException e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Photo failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}});}

    @Override public void onRequestPermissionsResult(int c,@NonNull String[] p,@NonNull int[] r){super.onRequestPermissionsResult(c,p,r);if(c==REQ_CAMERA&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)startCamera();else Toast.makeText(this,"Camera permission is required.",Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){super.onDestroy();if(cameraExecutor!=null)cameraExecutor.shutdown();}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    public static class GridOverlay extends View{private final android.graphics.Paint paint=new android.graphics.Paint();public GridOverlay(android.content.Context c){super(c);paint.setColor(Color.argb(100,255,255,255));paint.setStrokeWidth(1f);}protected void onDraw(android.graphics.Canvas c){float w=getWidth(),h=getHeight();c.drawLine(w/3,0,w/3,h,paint);c.drawLine(2*w/3,0,2*w/3,h,paint);c.drawLine(0,h/3,w,h/3,paint);c.drawLine(0,2*h/3,w,2*h/3,paint);}}
}
