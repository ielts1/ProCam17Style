# ProCam17Style V3
CameraX-based Android camera app with vendor camera extensions when available: Auto, HDR, Night and Portrait/Bokeh, plus 4:3 high-quality JPEG, flash, exposure, tap-to-focus, pinch zoom and grid.

Important: extension modes depend on the phone's camera vendor. They cannot turn different hardware into an iPhone camera, but they can expose supported multi-frame HDR/night/portrait processing.
