package com.skp.procam17;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraControl;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExposureState;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.MeteringPointFactory;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_CAMERA = 1001;

    private FrameLayout root;
    private PreviewView previewView;
    private View gridView;
    private TextView flashButton, cameraButton, zoomButton, infoText;
    private TextView minusExposure, plusExposure;
    private View shutterButton;

    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ImageCapture imageCapture;
    private CameraSelector cameraSelector;
    private ExecutorService cameraExecutor;
    private boolean front = false;
    private boolean grid = false;
    private int flashMode = ImageCapture.FLASH_MODE_AUTO;
    private float currentZoom = 1f;
    private int exposureIndex = 0;
    private ScaleGestureDetector scaleDetector;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);
        setContentView(root);

        buildUi();
        cameraExecutor = Executors.newSingleThreadExecutor();

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                if (camera != null) {
                    float next = currentZoom * detector.getScaleFactor();
                    CameraInfo info = camera.getCameraInfo();
                    float min = info.getZoomState().getValue().getMinZoomRatio();
                    float max = info.getZoomState().getValue().getMaxZoomRatio();
                    currentZoom = Math.max(min, Math.min(max, next));
                    camera.getCameraControl().setZoomRatio(currentZoom);
                    updateZoomText();
                }
                return true;
            }
        });

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        } else {
            startCamera();
        }
    }

    private void buildUi() {
        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));

        gridView = new GridOverlay(this);
        gridView.setVisibility(View.GONE);
        root.addView(gridView, new FrameLayout.LayoutParams(-1, -1));

        // Top bar
        FrameLayout top = new FrameLayout(this);
        top.setPadding(dp(12), dp(8), dp(12), dp(8));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(62), Gravity.TOP);
        root.addView(top, tp);

        flashButton = pill("AUTO");
        addTop(top, flashButton, Gravity.START);
        flashButton.setOnClickListener(v -> cycleFlash());

        TextView gridButton = pill("GRID");
        addTop(top, gridButton, Gravity.CENTER_HORIZONTAL);
        gridButton.setOnClickListener(v -> {
            grid = !grid;
            gridView.setVisibility(grid ? View.VISIBLE : View.GONE);
            gridButton.setAlpha(grid ? 1f : .65f);
        });

        cameraButton = pill("↻");
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(52), dp(44), Gravity.END);
        cp.rightMargin = dp(6);
        cp.topMargin = dp(8);
        top.addView(cameraButton, cp);
        cameraButton.setTextSize(22);
        cameraButton.setOnClickListener(v -> {
            front = !front;
            startCamera();
        });

        infoText = new TextView(this);
        infoText.setText("PROCAM 17 STYLE");
        infoText.setTextColor(Color.WHITE);
        infoText.setTextSize(11);
        infoText.setGravity(Gravity.CENTER);
        infoText.setAlpha(.8f);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-2, dp(36), Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        ip.topMargin = dp(68);
        root.addView(infoText, ip);

        // Zoom row
        FrameLayout zoomBar = new FrameLayout(this);
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-1, dp(48), Gravity.BOTTOM);
        zp.bottomMargin = dp(126);
        root.addView(zoomBar, zp);
        zoomButton = pill("1×");
        zoomButton.setOnClickListener(v -> cycleZoom());
        FrameLayout.LayoutParams zbp = new FrameLayout.LayoutParams(dp(76), dp(42), Gravity.CENTER);
        zoomBar.addView(zoomButton, zbp);

        minusExposure = pill("−");
        plusExposure = pill("+");
        FrameLayout.LayoutParams ep1 = new FrameLayout.LayoutParams(dp(50), dp(42), Gravity.CENTER);
        ep1.leftMargin = dp(22);
        zoomBar.addView(minusExposure, ep1);
        FrameLayout.LayoutParams ep2 = new FrameLayout.LayoutParams(dp(50), dp(42), Gravity.CENTER);
        ep2.gravity = Gravity.END|Gravity.CENTER_VERTICAL;
        ep2.rightMargin = dp(22);
        zoomBar.addView(plusExposure, ep2);
        minusExposure.setOnClickListener(v -> changeExposure(-1));
        plusExposure.setOnClickListener(v -> changeExposure(1));

        // Shutter
        shutterButton = new View(this);
        shutterButton.setBackground(circle(Color.WHITE));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(82), dp(82), Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = dp(32);
        root.addView(shutterButton, sp);
        shutterButton.setOnClickListener(v -> takePhoto());

        TextView hint = new TextView(this);
        hint.setText("Tap preview to focus • Pinch to zoom");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(10);
        hint.setAlpha(.65f);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, dp(30), Gravity.BOTTOM);
        hp.bottomMargin = dp(6);
        root.addView(hint, hp);

        previewView.setOnTouchListener((v, event) -> {
            scaleDetector.onTouchEvent(event);
            if (event.getAction() == MotionEvent.ACTION_UP && camera != null) {
                MeteringPointFactory factory = previewView.getMeteringPointFactory();
                FocusMeteringAction action = new FocusMeteringAction.Builder(
                        factory.createPoint(event.getX(), event.getY()))
                        .setAutoCancelDuration(3, TimeUnit.SECONDS).build();
                camera.getCameraControl().startFocusAndMetering(action);
            }
            return true;
        });
    }

    private void addTop(FrameLayout parent, View v, int gravity) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(72), dp(44), gravity);
        p.topMargin = dp(8);
        parent.addView(v, p);
    }

    private TextView pill(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setBackground(round(Color.argb(150, 0, 0, 0), dp(20)));
        t.setPadding(dp(5), 0, dp(5), 0);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), Color.argb(80,255,255,255));
        return d;
    }

    private GradientDrawable circle(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setShape(GradientDrawable.OVAL);
        d.setStroke(dp(4), Color.WHITE);
        return d;
    }

    private void startCamera() {
        cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(front ? CameraSelector.LENS_FACING_FRONT : CameraSelector.LENS_FACING_BACK)
                .build();

        ListenableFuture<ProcessCameraProvider> future =
                ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .setJpegQuality(100)
                        .setFlashMode(flashMode)
                        .build();

                cameraProvider.unbindAll();
                camera = cameraProvider.bindToLifecycle(
                        this, cameraSelector, preview, imageCapture);

                float min = camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();
                float max = camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();
                currentZoom = Math.max(min, Math.min(1f, max));
                camera.getCameraControl().setZoomRatio(currentZoom);
                updateZoomText();
                updateExposureButtons();
            } catch (Exception e) {
                Toast.makeText(this, "Camera start failed", Toast.LENGTH_LONG).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void cycleFlash() {
        if (flashMode == ImageCapture.FLASH_MODE_AUTO) flashMode = ImageCapture.FLASH_MODE_ON;
        else if (flashMode == ImageCapture.FLASH_MODE_ON) flashMode = ImageCapture.FLASH_MODE_OFF;
        else flashMode = ImageCapture.FLASH_MODE_AUTO;
        flashButton.setText(flashMode == ImageCapture.FLASH_MODE_AUTO ? "AUTO" :
                flashMode == ImageCapture.FLASH_MODE_ON ? "ON" : "OFF");
        if (imageCapture != null) imageCapture.setFlashMode(flashMode);
    }

    private void cycleZoom() {
        float min = camera == null ? .5f : camera.getCameraInfo().getZoomState().getValue().getMinZoomRatio();
        float max = camera == null ? 2f : camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();
        float next = currentZoom < .75f ? 1f : currentZoom < 1.5f ? 2f : min;
        currentZoom = Math.max(min, Math.min(max, next));
        if (camera != null) camera.getCameraControl().setZoomRatio(currentZoom);
        updateZoomText();
    }

    private void updateZoomText() {
        if (zoomButton == null) return;
        if (Math.abs(currentZoom - .5f) < .08f) zoomButton.setText("0.5×");
        else if (Math.abs(currentZoom - 1f) < .08f) zoomButton.setText("1×");
        else if (Math.abs(currentZoom - 2f) < .12f) zoomButton.setText("2×");
        else zoomButton.setText(String.format(Locale.US, "%.1f×", currentZoom));
    }

    private void changeExposure(int delta) {
        if (camera == null) return;
        ExposureState es = camera.getCameraInfo().getExposureState();
        if (!es.isExposureCompensationSupported()) return;
        int step = es.getExposureCompensationStep().getNumerator() == 0 ? 1 :
                es.getExposureCompensationStep().getNumerator();
        int min = es.getExposureCompensationRange().getLower();
        int max = es.getExposureCompensationRange().getUpper();
        exposureIndex = Math.max(min, Math.min(max, exposureIndex + delta * step));
        camera.getCameraControl().setExposureCompensationIndex(exposureIndex);
        updateExposureButtons();
    }

    private void updateExposureButtons() {
        if (camera == null) return;
        boolean supported = camera.getCameraInfo().getExposureState().isExposureCompensationSupported();
        minusExposure.setAlpha(supported ? 1f : .35f);
        plusExposure.setAlpha(supported ? 1f : .35f);
    }

    private void takePhoto() {
        if (imageCapture == null) return;
        shutterButton.animate().scaleX(.88f).scaleY(.88f).setDuration(70)
                .withEndAction(() -> shutterButton.animate().scaleX(1f).scaleY(1f).setDuration(90)).start();

        String name = "ProCam17_" + new SimpleDateFormat(
                "yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date()) + ".jpg";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam17Style");

        ImageCapture.OutputFileOptions out = new ImageCapture.OutputFileOptions.Builder(
                getContentResolver(),
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build();

        imageCapture.takePicture(out, cameraExecutor,
                new ImageCapture.OnImageSavedCallback() {
                    @Override public void onImageSaved(@NonNull ImageCapture.OutputFileResults result) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                                "Photo saved to Gallery", Toast.LENGTH_SHORT).show());
                    }
                    @Override public void onError(@NonNull ImageCaptureException e) {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this,
                                "Photo failed: " + e.getImageCaptureError(), Toast.LENGTH_SHORT).show());
                    }
                });
    }

    @Override public void onRequestPermissionsResult(int requestCode,
            @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_CAMERA && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) startCamera();
        else Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_LONG).show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    public static class GridOverlay extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint();
        public GridOverlay(android.content.Context c) {
            super(c);
            paint.setColor(Color.argb(110,255,255,255));
            paint.setStrokeWidth(1f);
        }
        @Override protected void onDraw(android.graphics.Canvas c) {
            float w=getWidth(), h=getHeight();
            c.drawLine(w/3,0,w/3,h,paint);
            c.drawLine(2*w/3,0,2*w/3,h,paint);
            c.drawLine(0,h/3,w,h/3,paint);
            c.drawLine(0,2*h/3,w,2*h/3,paint);
        }
    }
}
