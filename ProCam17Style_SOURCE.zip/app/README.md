# ProCam17Style app module

This archive is the complete `app/` module with the Android source files placed
in their required directories.

Expected parent project structure:

ProCam17Style_FIXED/
  app/
    build.gradle
    src/main/...
  build.gradle
  settings.gradle
  gradle.properties

Do not open the `app` directory as a standalone project.
