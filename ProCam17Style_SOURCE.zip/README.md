# ProCam17Style

Android camera project built with CameraX.

Open the **project root folder** (`ProCam17Style_FIXED_READY`) in Code on the Go, not the `app` folder.

Features: rear/front camera, flash modes, zoom, pinch zoom, tap focus, exposure compensation, grid, and high-quality JPEG saving to Pictures/ProCam17Style.
